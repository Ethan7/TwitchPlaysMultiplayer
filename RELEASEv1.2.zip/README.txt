First run the prerequisite library installer, unless you haven't installed python, in which case do that first.

Then edit main.py, by adding your username and oauth key from twitch in the spaces on lines 200 and 201

Then run the main.py code and stream away, every user in chat will get a physics player

Press space to move all physics player's to the random points on the screen

Hold right click, drag, and release to create floating platforms

Left click and drag physics players to move them to a desired location or drag an objective marker around

Middle click to remove floating platforms

If players reach the objective marker it resets the field and gives that player their name on the background

Be sure to tell your twitch chat to use:
"input:left" to move left
"input:right" to move right
"input:jump" to jump up
"input:leftjump" to jump left
"input:rightjump" to jump right
"input:random" to move at a random speed in a random direction

Bugs:
	- Moving the objective directly onto the player causes a crash